# AVHIRAL Coovhiral Studio Pro 5.1.0

Coovhiral 5.1 poursuit la rupture amorcee avec la 5.0 : la branche professionnelle 3D ne repose
plus sur la demonstration 2D/D3D11. Le moteur `engine3d` utilise Direct3D 12, un vrai Z-buffer,
un pipeline HLSL et un terrain 3D indexe rendu par le GPU.

La 5.1 vise un premier saut visuel concret vers une scene de montagne moderne. Elle ne pretend
pas encore egaler a elle seule un moteur AAA avec photogrammetrie, RTX Mega Geometry/Nanite,
textures PBR 8K, IBL, shadow maps multi-cascades et assets artistiques professionnels. En revanche,
`examples/19_montagne_gpu_pbr.coo` n'est plus une scene faite de primitives 2D : le runtime cree
un relief haute densite, de la vegetation instanciee, une eau animee, un ciel procedural et un
shading metal/roughness sur D3D12.

## Nouveautes 5.1

- Terrain alpin/canyon/island procedural deterministe, jusqu'a 513 x 513 sommets en Ultra.
- Maillage indexe : 524 288 triangles de terrain en 513 x 513, avant eau et vegetation.
- Normales calculees depuis le relief, pente, cavites et auto-ombrage de terrain pre-calcule.
- Materiau alpin procedural GPU : herbe, roche, haute montagne et neige selon altitude/pente.
- BRDF metal/roughness de type PBR avec GGX/Fresnel-Schlick et tone mapping ACES.
- Eau 3D au niveau parametrable avec normales animees et reflet de ciel approche.
- Ciel plein ecran GPU : gradient atmospherique, soleil et nuages proceduraux.
- Brouillard de distance et attenuation par altitude.
- Vegetation GPU par `DrawIndexedInstanced`, jusqu'a 150 000 instances acceptees par cette release.
- Placement des arbres filtre par pente, altitude, eau, densite et seed.
- Camera free-flight : WASD/fleches, Q/E, Shift et clic droit + souris.
- Diagnostic temps reel : FPS, frame time, triangles de scene, instances et VRAM.
- Syntaxe terrain enrichie : `profile:`, `resolution:`, `size:`, `height_scale:`, `detail:`,
  `snow_line:`, `water_level:` et `seed:`.
- Syntaxe vegetation enrichie : `min_scale:`, `max_scale:` et `max_slope:`.
- Les modules 5.0 restent presents : GPU compute D3D12, telecom, AES-256-GCM/CNG, reseau,
  CPU, audio, systeme et compatibilite D3D11 historique.

## Demonstration montagne 5.1

```coovhiral
app graphical
use engine3d
use terrain
use vegetation

fn main() {
    world scene
    scene.renderer = directx12
    scene.quality = ultra
    scene.enable_hdr()

    terrain alpine = scene.load_terrain(
        "procedural://alpine",
        material: "builtin://alpine-pbr",
        profile: alpine,
        resolution: 513,
        size: 1450.0f,
        height_scale: 330.0f,
        detail: 1.18f,
        snow_line: 0.70f,
        water_level: 0.155f,
        seed: 20260921u
    )

    alpine.scatter(
        model: "builtin://pine-lowpoly",
        count: 120000,
        density: 0.74f,
        gpu_instancing: true,
        lod: automatic,
        min_scale: 2.6f,
        max_scale: 7.8f,
        max_slope: 0.40f
    )

    scene.sun.direction = {-0.42f, -0.76f, 0.34f}
    scene.sun.intensity = 6.2f
    scene.atmosphere.enable()
    scene.fog.volumetric = true

    camera player = scene.create_camera()
    player.position = {0.0f, 165.0f, -390.0f}
    player.pitch_degrees = -12.0f
    return scene.run(player, L"Coovhiral 5.1 - Montagne GPU PBR")
}
```

Pour juger la 5.1, utiliser `examples/19_montagne_gpu_pbr.coo`. L'ancien
`15_paysage_3d_texture_musique.coo` est conserve uniquement comme exemple legacy D3D11/2D et ne
represente plus le niveau graphique vise par la branche 5.x.

## Ce qui est reellement GPU

Le rasterizer, le Z-buffer, les vertex/pixel shaders, le terrain affiche, l'eau, le ciel et le
shading sont executes par Direct3D 12. La vegetation utilise `DrawIndexedInstanced` : le maillage
de l'arbre est partage et un buffer d'instances transporte positions, echelles, rotations et
variations de teinte. Le module `gpu::compute_program12` reste disponible pour les calculs HLSL
generiques, notamment telecom.

La generation initiale du relief et le placement statistique des arbres sont encore prepares sur
CPU au chargement dans la 5.1, puis transferes au GPU. Les prochaines etapes porteront le culling,
les LOD et une partie du traitement vers compute/ExecuteIndirect/Mesh Shaders lorsque le materiel
le permet.

## Limites visuelles connues de la 5.1

Le rendu est structurellement bien plus avance que la demonstration 4.x/15, mais le
photoréalisme d'une reference de montagne satellite/photogrammetrique exige aussi du contenu et
des passes qui ne sont pas encore dans ce paquet : import glTF/GLB complet, textures PBR haute
resolution, IBL/HDRI, Cascaded Shadow Maps dynamiques, LOD/clipmap de terrain, TAA, framebuffer
FP16/HDR10, bloom/color grading, reflets SSR/planaires, culling GPU + ExecuteIndirect et chemins
Mesh Shader/DXR actifs.

Les API `scene.enable_taa()`, `scene.enable_bloom()`, `scene.enable_gpu_culling()` et
`scene.enable_streaming()` sont conservees pour stabiliser le langage mais leurs passes completes
ne sont pas encore implementees; ces flags sont desactives par defaut. `scene.sun.shadows = cascaded`
ne produit pas encore quatre shadow maps dynamiques. `scene.enable_hdr()` active actuellement le
tone mapping, pas une sortie HDR10/scRGB.

`docs/IMPLEMENTATION_STATUS.md` fait foi pour distinguer les fonctions actives des fonctions de
roadmap.

## Calcul GPU, telecom et cryptographie

Coovhiral 5.1 conserve `gpu::compute_program12`, neutre vis-a-vis de CUDA et utilisable via
Direct3D 12 sur NVIDIA, AMD ou Intel selon le pilote. Les primitives telecom fournissent I/Q,
QPSK, FFT radix-2 et OFDM. La cryptographie ne repose pas sur un algorithme proprietaire : AES-
256-GCM, SHA-256/512, HMAC, PBKDF2 et RNG utilisent Windows CNG/Bcrypt.

## Construction Windows

Prerequis : Windows 10/11 x64, Visual Studio 2022 ou Build Tools 2022 avec Desktop C++ x64, SDK
Windows recent et CMake. Inno Setup 6 est requis uniquement pour fabriquer le setup.

```bat
BUILD_ALL.bat
CREER_SETUP_WINDOWS.bat
```

Le script compile le runtime, le compilateur `cooc`, le runner `coo`, le Studio et le moteur
Retro. Il valide tous les exemples `.coo` et compile le C++ genere des demonstrations critiques,
dont `19_montagne_gpu_pbr.coo`.

Une fois le paquet portable construit, l'execution d'un programme se fait avec :

```bat
coo examples\19_montagne_gpu_pbr.coo
```

## Validation de la source livree

Dans l'environnement de generation, les controles portables suivants passent :

```text
Coovhiral frontend: 7 tests + 17 exemples OK
Terrain 5.1 OK: 16641 vertices, 32768 triangles
Coovhiral 5.1.0 tree OK: 17 exemples, 121 entrees
```

L'environnement de generation n'inclut pas MSVC ni le SDK Direct3D 12. Le backend Win32/D3D12
doit donc encore etre compile et execute sur Windows avec `BUILD_ALL.bat`. Le fichier
`docs/BUILD_VALIDATION_5_1.txt` documente exactement cette limite.

## Arborescence

```text
compiler/                 frontend/transpileur et runner
runtime/include/coo/      API publique Coovhiral
runtime/src/              runtime natif D3D12/D3D11/CPU/reseau/crypto
studio/                   IDE Win32
stdlib/                   modules Coovhiral
examples/                 demonstrations et tests utilisateur
docs/                     architecture, statut, roadmap et manuel
installer/                setup Inno Setup
```

## Fichiers a lire

- `docs/ARCHITECTURE.md` : architecture 5.1.
- `docs/IMPLEMENTATION_STATUS.md` : fonctions actives et limites exactes.
- `docs/ROADMAP_5.md` : prochaines etapes vers le rendu AAA.
- `docs/VISUAL_TARGET_5_1.md` : ce que la reference montagne implique techniquement.
- `docs/BUILD_VALIDATION_5_1.txt` : tests effectues et limite de validation Windows.
- `docs/MANUEL_COOVHIRAL_STUDIO_PRO_5.pdf` : manuel 5.1.

## Positionnement par rapport a Python

Coovhiral n'est pas universellement "plus puissant que Python". Son objectif est different :
code natif C++20/MSVC, integration Windows directe, Direct3D 12, GPU compute, reseau bas niveau,
CNG et executable sans interpreteur Python embarque. Python conserve un ecosysteme scientifique,
IA et data beaucoup plus vaste. La valeur de Coovhiral doit venir de son runtime, de ses outils et
de performances mesurees par workload.

## Licence

Coovhiral Studio Pro reste distribue sous la licence freeware fournie dans `installer/`.

Soutien facultatif AVHIRAL : https://www.paypal.com/donate/?hosted_button_id=FSX7RHUT4BDRY
