# Faux positif Bitdefender - Coovhiral Studio Pro

Coovhiral est un compilateur : il cree des executables, appelle les outils MSVC
et peut lancer le programme produit. Ces actions legitimes sont aussi surveillees
par les moteurs comportementaux. Un binaire nouveau et non signe peut donc etre
classe par erreur comme suspect.

## Ne pas desactiver toute la protection

1. Relever le nom exact de la detection et le chemin du fichier bloque.
2. Verifier que l'archive utilisee provient d'AVHIRAL et comparer son SHA-256.
3. Restaurer uniquement le fichier Coovhiral place en quarantaine.
4. Pendant une compilation locale, ajouter si necessaire une exclusion temporaire
   limitee au dossier `build-nmake-x64`, jamais au disque complet.
5. Supprimer cette exclusion apres la compilation.
6. Envoyer le fichier detecte au support Bitdefender comme faux positif.

## Signature officielle AVHIRAL

La solution durable pour une distribution publique consiste a utiliser un
certificat Authenticode de signature de code emis a AVHIRAL par une autorite de
certification reconnue. Un certificat auto-signe ne cree pas de reputation
publique et ne garantit pas la disparition des alertes.

Apres installation du certificat dans le magasin Windows de l'utilisateur :

```powershell
$env:AVHIRAL_SIGN_CERT_SHA1 = "EMPREINTE_SHA1_DU_CERTIFICAT"
.\CREER_SETUP_WINDOWS.bat
```

Le script signe alors `coo.exe`, `cooc.exe`, `coovhiral_studio.exe` et
`setup_coovhiral.exe` avec SHA-256 et horodatage, puis verifie chaque signature.

Verification manuelle :

```powershell
Get-AuthenticodeSignature .\dist\setup_coovhiral.exe | Format-List
Get-FileHash .\dist\setup_coovhiral.exe -Algorithm SHA256
```

La signature diminue fortement les faux positifs, mais une detection erronee
doit toujours etre signalee au fournisseur antivirus afin que sa base soit
corrigee.
