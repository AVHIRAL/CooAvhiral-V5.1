#pragma once

#include <cstddef>
#include <cstdint>
#include <filesystem>
#include <string>
#include <string_view>

namespace coo::system {

class dynamic_library {
public:
    dynamic_library() = default;
    explicit dynamic_library(const std::wstring& path) { open(path); }
    ~dynamic_library();
    dynamic_library(const dynamic_library&) = delete;
    dynamic_library& operator=(const dynamic_library&) = delete;
    dynamic_library(dynamic_library&& other) noexcept;
    dynamic_library& operator=(dynamic_library&& other) noexcept;

    bool open(const std::wstring& path);
    void close();
    void* symbol(std::string_view name) const;
    template<class Function> Function function(std::string_view name) const {
        return reinterpret_cast<Function>(symbol(name));
    }
    explicit operator bool() const { return module_ != nullptr; }
private:
    void* module_{};
};

class virtual_memory {
public:
    virtual_memory() = default;
    explicit virtual_memory(std::size_t bytes, bool executable = false);
    ~virtual_memory();
    virtual_memory(const virtual_memory&) = delete;
    virtual_memory& operator=(const virtual_memory&) = delete;
    virtual_memory(virtual_memory&& other) noexcept;
    virtual_memory& operator=(virtual_memory&& other) noexcept;

    bool allocate(std::size_t bytes, bool executable = false);
    void release();
    void* data() { return data_; }
    const void* data() const { return data_; }
    std::size_t size() const { return size_; }
    explicit operator bool() const { return data_ != nullptr; }
private:
    void* data_{};
    std::size_t size_{};
};

std::string environment(std::string_view name);
bool set_environment(std::string_view name, std::string_view value);
std::filesystem::path executable_path();
std::filesystem::path executable_directory();
std::uint64_t process_memory_bytes();
void debug_output(std::string_view message);

} // namespace coo::system

