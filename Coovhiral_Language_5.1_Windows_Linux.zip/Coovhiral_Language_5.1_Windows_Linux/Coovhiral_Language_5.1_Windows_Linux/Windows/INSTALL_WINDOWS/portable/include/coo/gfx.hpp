#pragma once

#include <windows.h>
#include <cstdint>
#include <memory>
#include <string>
#include <string_view>

namespace coo::gfx {

struct color {
    float r{}, g{}, b{}, a{1.0f};
    static color rgb8(unsigned red, unsigned green, unsigned blue, unsigned alpha = 255) {
        return {red / 255.0f, green / 255.0f, blue / 255.0f, alpha / 255.0f};
    }
};

struct point { float x{}, y{}; };

class window {
public:
    window();
    ~window();
    window(const window&) = delete;
    window& operator=(const window&) = delete;
    window(window&&) noexcept;
    window& operator=(window&&) noexcept;

    // Borderless est active par defaut : aucun cadre inutile autour des jeux.
    bool create(const std::wstring& title, int width, int height, bool borderless = true);
    bool pump();
    void request_close();
    bool should_close() const;

    void begin_frame(color clear = {0.02f, 0.025f, 0.05f, 1.0f});
    void draw_rect(float x, float y, float width, float height, color value);
    // Triangles pleins acceleres par Direct3D 11. La variante gradient
    // interpole les trois couleurs et permet des materiaux proceduraux.
    void draw_triangle(point a, point b, point c, color value);
    void draw_triangle_gradient(point a, color ca, point b, color cb,
                                point c, color cc);
    void draw_quad(point a, point b, point c, point d, color value);
    void draw_line(point from, point to, float thickness, color value);
    void draw_circle(point center, float radius, color value, unsigned segments = 48);
    void draw_text(float x, float y, std::wstring_view text, color value,
                   int pixel_height = 22, bool bold = false);
    void present(bool vsync = true);

    bool key_down(int virtual_key) const;
    bool key_pressed(int virtual_key);
    point mouse_position() const;
    void show_cursor(bool visible);
    void set_fullscreen(bool enabled);

    int width() const;
    int height() const;
    double delta_seconds() const;
    std::uint64_t frame_index() const;
    std::wstring adapter_name() const;
    bool hardware_accelerated() const;
    HWND native_handle() const;

private:
    struct implementation;
    std::unique_ptr<implementation> impl_;
    static LRESULT CALLBACK window_proc(HWND, UINT, WPARAM, LPARAM);
};

} // namespace coo::gfx
