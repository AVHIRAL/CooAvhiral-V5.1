#pragma once

#include <cstdint>
#include <cstddef>
#include <span>
#include <string>
#include <vector>

namespace coo::kernel {

struct ioctl_result {
    bool success{};
    std::uint32_t windows_error{};
    std::vector<std::uint8_t> output;
};

// Pont de laboratoire vers un pilote Windows deja installe et signe. Ce module
// n'installe aucun pilote, ne contourne pas la signature Windows et reste en mode
// utilisateur. Les codes IOCTL doivent provenir du contrat public du pilote.
class device {
public:
    device() = default;
    ~device();
    device(const device&) = delete;
    device& operator=(const device&) = delete;
    device(device&& other) noexcept;
    device& operator=(device&& other) noexcept;

    bool open(const std::wstring& path, bool read = true, bool write = true);
    ioctl_result control(std::uint32_t code, std::span<const std::uint8_t> input = {},
                         std::size_t output_capacity = 0);
    void close();
    bool valid() const;
    std::uint32_t last_error() const { return last_error_; }

private:
    void* handle_{reinterpret_cast<void*>(static_cast<std::intptr_t>(-1))};
    std::uint32_t last_error_{};
};

bool is_elevated();
bool service_installed(const std::wstring& service_name);

} // namespace coo::kernel
