#pragma once

#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WINVER
#define WINVER 0x0A00
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0A00
#endif

#include <windows.h>
#include <algorithm>
#include <array>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <functional>
#include <future>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

#include "types.hpp"
#include "audio.hpp"
#include "audio3d.hpp"
#include "cpu.hpp"
#include "crypto.hpp"
#include "gfx.hpp"
#include "gpu.hpp"
#include "engine3d.hpp"
#include "kernel.hpp"
#include "net.hpp"
#include "scene3d.hpp"
#include "telecom.hpp"
#include "system.hpp"

namespace coo {

inline constexpr std::string_view version = "5.1.0";

struct runtime_config {
    static inline bool borderless = true;
    static inline bool vsync = true;
    static inline bool high_resolution_timer = true;
};

void initialize_runtime();
void shutdown_runtime();
void set_arguments(int argc, char** argv);
void set_arguments_wide(int argc, wchar_t** argv);
const std::vector<std::string>& arguments();
std::string argument(std::size_t index, std::string fallback = {});

void print(const std::string& value);
void eprint(const std::string& value);
template<class... T> void print(const T&... values) { (std::cout << ... << values); }
template<class... T> void println(const T&... values) { (std::cout << ... << values) << '\n'; }
template<class... T> void eprintln(const T&... values) { (std::cerr << ... << values) << '\n'; }

void sleep_ms(int milliseconds);
std::uint64_t ticks_ms();
double high_res_seconds();
int cpu_threads();
std::wstring widen(std::string_view utf8);
std::string narrow(std::wstring_view utf16);

class stopwatch {
public:
    stopwatch() : start_(std::chrono::steady_clock::now()) {}
    void reset() { start_ = std::chrono::steady_clock::now(); }
    double seconds() const {
        return std::chrono::duration<double>(std::chrono::steady_clock::now() - start_).count();
    }
    double milliseconds() const { return seconds() * 1000.0; }
private:
    std::chrono::steady_clock::time_point start_;
};

class integer_range {
public:
    struct iterator {
        long long value{}, step{1};
        long long operator*() const { return value; }
        iterator& operator++() { value += step; return *this; }
        bool operator!=(const iterator& other) const {
            return step > 0 ? value < other.value : value > other.value;
        }
    };
    integer_range(long long begin, long long end, long long step)
        : begin_(begin), end_(end), step_(step == 0 ? 1 : step) {}
    iterator begin() const { return {begin_, step_}; }
    iterator end() const { return {end_, step_}; }
private:
    long long begin_{}, end_{}, step_{1};
};

inline integer_range range(long long end) { return {0, end, 1}; }
inline integer_range range(long long begin, long long end, long long step = 1) {
    return {begin, end, step};
}

template<class F> class scope_exit {
public:
    explicit scope_exit(F function) : function_(std::move(function)) {}
    scope_exit(scope_exit&& other) noexcept
        : function_(std::move(other.function_)), active_(std::exchange(other.active_, false)) {}
    ~scope_exit() { if (active_) function_(); }
    scope_exit(const scope_exit&) = delete;
    scope_exit& operator=(const scope_exit&) = delete;
private:
    F function_;
    bool active_{true};
};

template<class F> scope_exit<F> defer(F function) { return scope_exit<F>(std::move(function)); }

} // namespace coo
