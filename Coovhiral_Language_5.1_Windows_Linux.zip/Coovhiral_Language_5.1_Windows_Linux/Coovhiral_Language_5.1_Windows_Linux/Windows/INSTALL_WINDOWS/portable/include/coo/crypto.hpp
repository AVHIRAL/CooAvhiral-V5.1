#pragma once

#include <cstddef>
#include <cstdint>
#include <optional>
#include <span>
#include <string>
#include <vector>

namespace coo::crypto {

using bytes = std::vector<std::uint8_t>;

struct aes_gcm_packet {
    bytes nonce;
    bytes ciphertext;
    bytes tag;
};

bytes random_bytes(std::size_t count);
bytes sha256(std::span<const std::uint8_t> data);
bytes sha512(std::span<const std::uint8_t> data);
bytes hmac_sha256(std::span<const std::uint8_t> key, std::span<const std::uint8_t> data);
bytes pbkdf2_sha256(std::string_view password, std::span<const std::uint8_t> salt,
                    std::uint64_t iterations, std::size_t output_bytes = 32);
aes_gcm_packet aes256_gcm_encrypt(std::span<const std::uint8_t> key,
                                  std::span<const std::uint8_t> plaintext,
                                  std::span<const std::uint8_t> aad = {},
                                  std::span<const std::uint8_t> nonce = {});
std::optional<bytes> aes256_gcm_decrypt(std::span<const std::uint8_t> key,
                                        const aes_gcm_packet& packet,
                                        std::span<const std::uint8_t> aad = {});
bool constant_time_equal(std::span<const std::uint8_t> a,
                         std::span<const std::uint8_t> b) noexcept;
std::string hex(std::span<const std::uint8_t> data);
bytes from_hex(std::string_view value);

} // namespace coo::crypto
