#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include <vector>

namespace coo {
using i8 = std::int8_t;
using u8 = std::uint8_t;
using i16 = std::int16_t;
using u16 = std::uint16_t;
using i32 = std::int32_t;
using u32 = std::uint32_t;
using i64 = std::int64_t;
using u64 = std::uint64_t;
using f32 = float;
using f64 = double;
using string = std::string;
using wstring = std::wstring;
template<class T> using array = std::vector<T>;
template<class K, class V> using dictionary = std::unordered_map<K, V>;

struct vec2 { float x{}, y{}; };
struct vec3 { float x{}, y{}, z{}; };
struct vec4 { float x{}, y{}, z{}, w{}; };
}
