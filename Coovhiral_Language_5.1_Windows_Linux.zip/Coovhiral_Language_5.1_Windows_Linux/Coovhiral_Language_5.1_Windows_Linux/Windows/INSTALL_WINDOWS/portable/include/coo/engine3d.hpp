#pragma once

#include <cstdint>
#include <memory>
#include <string>
#include <vector>
#include "types.hpp"

namespace coo::engine3d {

enum class renderer_backend { directx12, legacy_d3d11 };
enum class quality_preset { low, medium, high, ultra };
enum class shadow_mode { off, cascaded };
enum class camera_controller { free_flight, orbit };
enum class lod_mode { manual, automatic };
enum class terrain_profile { heightmap, alpine, canyon, island };

struct renderer_capabilities {
    std::wstring adapter_name;
    std::uint64_t dedicated_vram{};
    std::uint64_t local_vram_usage{};
    std::uint32_t feature_level_major{};
    std::uint32_t feature_level_minor{};
    bool hardware_accelerated{};
    bool raytracing{};
    bool mesh_shaders{};
    bool sampler_feedback{};
    bool variable_rate_shading{};
};

struct renderer_statistics {
    double fps{};
    double frame_ms{};
    std::uint64_t frame_index{};
    std::uint64_t local_vram_usage{};
    std::uint64_t triangles{};
    std::uint64_t instances{};
    std::uint32_t draw_calls{};
};

// 5.1 : les champs apres material ont tous une valeur par defaut afin que les
// sources 5.0 terrain_options{"..."} restent compatibles.
struct terrain_options {
    std::string material;
    terrain_profile profile{terrain_profile::alpine};
    std::uint32_t resolution{513};
    float size{1200.0f};
    float height_scale{260.0f};
    float detail{1.0f};
    float snow_line{0.69f};
    float water_level{0.16f};
    std::uint32_t seed{1337u};
};

struct scatter_options {
    std::string model;
    std::uint32_t count{};
    float density{1.0f};
    bool gpu_instancing{true};
    lod_mode lod{lod_mode::automatic};
    float min_scale{2.4f};
    float max_scale{7.5f};
    float max_slope{0.42f};
};

class terrain {
public:
    terrain();
    terrain(std::string heightmap, terrain_options options);
    void scatter(scatter_options options);
    const std::string& heightmap() const noexcept;
    const terrain_options& options() const noexcept;
    const std::vector<scatter_options>& scatters() const noexcept;
private:
    struct state;
    std::shared_ptr<state> state_;
};

class camera {
public:
    camera_controller controller{camera_controller::free_flight};
    coo::vec3 position{};
    float yaw_degrees{0.0f};
    float pitch_degrees{-12.0f};
    float move_speed{52.0f};
    float mouse_sensitivity{0.13f};
    float fov_degrees{68.0f};
    float near_plane{0.2f};
    float far_plane{6000.0f};
};

struct sun_state {
    coo::vec3 direction{-0.42f, -0.76f, 0.34f};
    shadow_mode shadows{shadow_mode::cascaded};
    float intensity{6.0f};
};

struct atmosphere_state {
    bool enabled{};
    float haze{0.72f};
    void enable(bool value = true) noexcept { enabled = value; }
};

struct fog_state {
    bool volumetric{};
    float density{0.0019f};
    float height_falloff{0.0065f};
};

class world {
public:
    renderer_backend renderer{renderer_backend::directx12};
    quality_preset quality{quality_preset::high};
    sun_state sun;
    atmosphere_state atmosphere;
    fog_state fog;

    world();
    ~world();
    world(const world&) = delete;
    world& operator=(const world&) = delete;
    world(world&&) noexcept;
    world& operator=(world&&) noexcept;

    void enable_hdr(bool value = true) noexcept;
    void enable_taa(bool value = true) noexcept;
    void enable_gpu_culling(bool value = true) noexcept;
    void enable_bloom(bool value = true) noexcept;
    void enable_streaming(bool value = true) noexcept;

    terrain load_terrain(std::string heightmap, terrain_options options = {});
    camera create_camera() const;
    int run(camera& active_camera, std::wstring title = L"Coovhiral Studio Pro 5.1 - Direct3D 12");

    renderer_capabilities capabilities() const;
    renderer_statistics statistics() const;
    const std::vector<terrain>& terrains() const noexcept { return terrains_; }

    bool hdr_enabled() const noexcept { return hdr_; }
    bool taa_enabled() const noexcept { return taa_; }
    bool gpu_culling_enabled() const noexcept { return gpu_culling_; }
    bool bloom_enabled() const noexcept { return bloom_; }
    bool streaming_enabled() const noexcept { return streaming_; }

private:
    struct implementation;
    std::unique_ptr<implementation> impl_;
    std::vector<terrain> terrains_;
    bool hdr_{true};
    bool taa_{false};
    bool gpu_culling_{false};
    bool bloom_{false};
    bool streaming_{false};
};

} // namespace coo::engine3d
