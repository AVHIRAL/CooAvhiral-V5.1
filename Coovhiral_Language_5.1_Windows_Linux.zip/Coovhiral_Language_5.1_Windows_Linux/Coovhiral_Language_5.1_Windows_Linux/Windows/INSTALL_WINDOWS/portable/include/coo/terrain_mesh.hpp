#pragma once

#include "engine3d.hpp"

#include <cstdint>
#include <vector>

namespace coo::engine3d::detail {

struct terrain_vertex {
    float x{}, y{}, z{};
    float nx{}, ny{1.0f}, nz{};
    // x=height normalisee, y=pente, z=occlusion, w=material id
    float a{}, b{}, c{1.0f}, d{};
};

struct terrain_mesh {
    std::vector<terrain_vertex> vertices;
    std::vector<std::uint32_t> indices;
    std::vector<float> heights;
    std::uint32_t resolution{};
    float size{};
    float min_height{};
    float max_height{};

    float sample_height(float world_x, float world_z) const noexcept;
    coo::vec3 sample_normal(float world_x, float world_z) const noexcept;
};

terrain_mesh generate_terrain_mesh(const terrain_options& options,
                                   coo::vec3 sun_direction = {-0.4f, -0.8f, 0.2f});

} // namespace coo::engine3d::detail
