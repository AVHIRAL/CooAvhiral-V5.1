#pragma once

#include "gfx.hpp"

#include <algorithm>
#include <cmath>

namespace coo::scene3d {

struct vector3 { float x{}, y{}, z{}; };

struct camera {
    vector3 position{0.0f, 0.0f, 0.0f};
    float focal{720.0f};
    float horizon{0.52f};
    float near_plane{0.25f};
};

inline vector3 rotate_x(vector3 value, float angle) {
    const float cosine = std::cos(angle), sine = std::sin(angle);
    return {value.x, value.y * cosine - value.z * sine,
        value.y * sine + value.z * cosine};
}

inline vector3 rotate_y(vector3 value, float angle) {
    const float cosine = std::cos(angle), sine = std::sin(angle);
    return {value.x * cosine + value.z * sine, value.y,
        -value.x * sine + value.z * cosine};
}

inline vector3 rotate_z(vector3 value, float angle) {
    const float cosine = std::cos(angle), sine = std::sin(angle);
    return {value.x * cosine - value.y * sine,
        value.x * sine + value.y * cosine, value.z};
}

inline gfx::point project(vector3 world, const camera& view, float width, float height) {
    const float x = world.x - view.position.x;
    const float y = world.y - view.position.y;
    const float z = std::max(view.near_plane, world.z - view.position.z);
    return {width * 0.5f + x * view.focal / z,
        height * view.horizon - y * view.focal / z};
}

inline float distance(vector3 left, vector3 right) {
    const float x = left.x - right.x, y = left.y - right.y, z = left.z - right.z;
    return std::sqrt(x * x + y * y + z * z);
}

inline gfx::color fog(gfx::color source, gfx::color atmosphere,
                      float distance_value, float start, float end) {
    const float amount = std::clamp((distance_value - start) /
        std::max(0.001f, end - start), 0.0f, 1.0f);
    return {source.r + (atmosphere.r - source.r) * amount,
        source.g + (atmosphere.g - source.g) * amount,
        source.b + (atmosphere.b - source.b) * amount,
        source.a + (atmosphere.a - source.a) * amount};
}

} // namespace coo::scene3d
