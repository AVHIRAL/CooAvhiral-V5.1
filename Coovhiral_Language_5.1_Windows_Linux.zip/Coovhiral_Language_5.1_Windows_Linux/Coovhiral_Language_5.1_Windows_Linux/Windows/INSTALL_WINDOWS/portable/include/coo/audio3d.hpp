#pragma once

#include "types.hpp"

namespace coo::audio3d {

struct spatial_result {
    float gain{1.0f};
    float pan{};
    float distance{};
};

spatial_result spatialize(const coo::vec3& listener, const coo::vec3& source,
                          float min_distance = 1.0f, float max_distance = 100.0f) noexcept;

} // namespace coo::audio3d
