#pragma once

#include <cstddef>
#include <cstdint>
#include <span>
#include <vector>

namespace coo::telecom {

struct complex32 { float i{}, q{}; };
using iq_buffer = std::vector<complex32>;

float magnitude(complex32 sample) noexcept;
float phase(complex32 sample) noexcept;
double signal_power_dbfs(std::span<const complex32> samples);
iq_buffer qpsk_modulate(std::span<const std::uint8_t> bits);
std::vector<std::uint8_t> qpsk_demodulate(std::span<const complex32> symbols);
void fft(iq_buffer& samples, bool inverse = false);
iq_buffer ofdm_symbol(std::span<const complex32> subcarriers, std::size_t cyclic_prefix);

} // namespace coo::telecom
