#pragma once

#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <vector>

namespace coo::gpu {

struct adapter_info {
    std::wstring name;
    std::uint32_t vendor_id{};
    std::uint32_t device_id{};
    std::uint64_t dedicated_video_memory{};
    std::uint64_t dedicated_system_memory{};
    std::uint64_t shared_system_memory{};
    bool software{};
    bool nvidia() const { return vendor_id == 0x10DE; }
    bool amd() const { return vendor_id == 0x1002 || vendor_id == 0x1022; }
    bool intel() const { return vendor_id == 0x8086; }
    std::wstring vendor_name() const {
        if (nvidia()) return L"NVIDIA";
        if (amd()) return L"AMD/ATI";
        if (intel()) return L"Intel";
        return software ? L"Microsoft/WARP" : L"Autre";
    }
};

enum class adapter_preference {
    automatic,
    high_performance,
    nvidia,
    amd,
    intel,
    warp
};

std::vector<adapter_info> adapters();
bool has_nvidia();
bool has_amd();
bool has_intel();
bool direct_compute_available();

// DirectCompute : compilation HLSL et calcul sur un buffer float structure.
// Le shader expose RWStructuredBuffer<float> data en u0 et un cbuffer Params
// contenant uint count en b0.
class compute_program {
public:
    compute_program();
    ~compute_program();
    compute_program(const compute_program&) = delete;
    compute_program& operator=(const compute_program&) = delete;
    compute_program(compute_program&&) noexcept;
    compute_program& operator=(compute_program&&) noexcept;

    // DirectCompute est une API DirectX neutre : automatic choisit le meilleur
    // adaptateur materiel disponible, qu'il soit NVIDIA, AMD/ATI ou Intel.
    bool create(adapter_preference preference = adapter_preference::automatic);
    bool create(bool prefer_nvidia) {
        return create(prefer_nvidia ? adapter_preference::nvidia : adapter_preference::automatic);
    }
    bool compile(std::string_view hlsl, std::string_view entry = "cs_main");
    bool upload(std::span<const float> values);
    bool dispatch(std::uint32_t element_count, std::uint32_t threads_per_group = 256);
    bool download(std::vector<float>& values);
    bool run(std::string_view hlsl, std::span<const float> input,
             std::vector<float>& output, std::uint32_t threads_per_group = 256);
    const std::string& last_error() const;
    std::wstring adapter_name() const;

private:
    struct implementation;
    std::unique_ptr<implementation> impl_;
};


// Direct3D 12 compute : backend moderne, neutre NVIDIA/AMD/Intel, sans CUDA.
// Le contrat HLSL est identique au backend historique : RWStructuredBuffer<float>
// en u0 et uint count en b0. Shader Model 5.1 est utilise pour conserver une
// compatibilite large D3D12 ; les chemins Shader Model 6 restent disponibles via DXC.
class compute_program12 {
public:
    compute_program12();
    ~compute_program12();
    compute_program12(const compute_program12&) = delete;
    compute_program12& operator=(const compute_program12&) = delete;
    compute_program12(compute_program12&&) noexcept;
    compute_program12& operator=(compute_program12&&) noexcept;

    bool create(adapter_preference preference = adapter_preference::high_performance);
    bool compile(std::string_view hlsl, std::string_view entry = "cs_main");
    bool upload(std::span<const float> values);
    bool dispatch(std::uint32_t element_count, std::uint32_t threads_per_group = 256);
    bool download(std::vector<float>& values);
    bool run(std::string_view hlsl, std::span<const float> input,
             std::vector<float>& output, std::uint32_t threads_per_group = 256);
    const std::string& last_error() const;
    std::wstring adapter_name() const;

private:
    struct implementation;
    std::unique_ptr<implementation> impl_;
};

// Pont optionnel vers CUDA Toolkit. Le runtime DirectCompute ne requiert pas CUDA.
int nvcc_compile(const std::wstring& cu_file, const std::wstring& out_file,
                 const std::wstring& extra = L"");

} // namespace coo::gpu
