#pragma once

#include <cstdint>
#include <memory>
#include <span>
#include <string>
#include <string_view>
#include <unordered_map>
#include <vector>

namespace coo::net {

using socket_value = std::uintptr_t;
inline constexpr socket_value invalid_socket = static_cast<socket_value>(-1);

class tcp_client {
public:
    tcp_client();
    ~tcp_client();
    tcp_client(const tcp_client&) = delete;
    tcp_client& operator=(const tcp_client&) = delete;
    tcp_client(tcp_client&& other) noexcept;
    tcp_client& operator=(tcp_client&& other) noexcept;

    bool connect(std::string_view host, std::uint16_t port, int timeout_ms = 5000);
    int send(const void* data, int bytes);
    bool send_all(std::span<const std::uint8_t> data);
    bool send_text(std::string_view text);
    int receive(void* data, int bytes);
    std::vector<std::uint8_t> receive_bytes(std::size_t maximum = 1024 * 1024);
    std::string receive_text(std::size_t maximum = 1024 * 1024);
    void set_timeouts(int receive_ms, int send_ms);
    void set_no_delay(bool enabled = true);
    void close();
    bool connected() const { return socket_ != invalid_socket; }
    socket_value native_handle() const { return socket_; }

private:
    explicit tcp_client(socket_value accepted);
    socket_value socket_{invalid_socket};
    friend class tcp_listener;
};

class tcp_listener {
public:
    tcp_listener();
    ~tcp_listener();
    tcp_listener(const tcp_listener&) = delete;
    tcp_listener& operator=(const tcp_listener&) = delete;
    bool listen(std::uint16_t port, std::string_view bind_address = "0.0.0.0", int backlog = 64);
    std::unique_ptr<tcp_client> accept(int timeout_ms = -1);
    void close();
    socket_value native_handle() const { return socket_; }
private:
    socket_value socket_{invalid_socket};
};

class udp_socket {
public:
    udp_socket();
    ~udp_socket();
    udp_socket(const udp_socket&) = delete;
    udp_socket& operator=(const udp_socket&) = delete;
    bool bind(std::uint16_t port, std::string_view address = "0.0.0.0");
    int send_to(std::string_view host, std::uint16_t port, std::span<const std::uint8_t> data);
    int broadcast(std::uint16_t port, std::span<const std::uint8_t> data);
    int receive_from(void* data, int bytes, std::string& sender, std::uint16_t& port, int timeout_ms = -1);
    void close();
private:
    bool ensure_socket();
    socket_value socket_{invalid_socket};
};

struct ping_result {
    bool success{};
    std::uint32_t round_trip_ms{};
    std::string address;
    std::uint32_t status{};
};

struct network_adapter {
    std::wstring name;
    std::wstring description;
    std::vector<std::string> addresses;
    std::uint64_t transmit_speed{};
    std::uint64_t receive_speed{};
    bool up{};
};

struct http_response {
    unsigned status{};
    std::unordered_map<std::string, std::string> headers;
    std::vector<std::uint8_t> body;
    std::string text() const { return {body.begin(), body.end()}; }
    bool ok() const { return status >= 200 && status < 300; }
};

http_response http_request(std::wstring_view method, std::wstring_view url,
    std::span<const std::uint8_t> body = {}, std::wstring_view content_type = L"application/octet-stream",
    int timeout_ms = 15000);
inline http_response http_get(std::wstring_view url, int timeout_ms = 15000) {
    return http_request(L"GET", url, {}, L"", timeout_ms);
}
http_response http_post(std::wstring_view url, std::string_view body,
    std::wstring_view content_type = L"application/json", int timeout_ms = 15000);

std::vector<std::string> resolve(std::string_view host);
std::string local_hostname();
bool ping_tcp(std::string_view host, std::uint16_t port, int timeout_ms = 1000);
ping_result ping_icmp(std::string_view host, int timeout_ms = 1000,
                      std::string_view payload = "Coovhiral");
std::vector<network_adapter> adapters();

} // namespace coo::net
