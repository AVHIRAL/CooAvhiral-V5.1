#pragma once

#include <algorithm>
#include <condition_variable>
#include <cstddef>
#include <functional>
#include <future>
#include <mutex>
#include <queue>
#include <string>
#include <thread>
#include <utility>
#include <vector>

namespace coo::cpu {

struct information {
    std::string vendor;
    std::string brand;
    unsigned logical_threads{};
    unsigned physical_cores{};
    bool sse2{};
    bool avx{};
    bool avx2{};
    bool avx512f{};
};

information query();
bool set_current_thread_affinity(unsigned logical_processor);
void set_current_thread_name(const std::wstring& name);

class thread_pool {
public:
    explicit thread_pool(unsigned workers = 0);
    ~thread_pool();
    thread_pool(const thread_pool&) = delete;
    thread_pool& operator=(const thread_pool&) = delete;

    std::future<void> submit(std::function<void()> work);
    unsigned size() const { return static_cast<unsigned>(workers_.size()); }
    void wait_idle();

private:
    void worker_loop(unsigned index);
    std::vector<std::thread> workers_;
    std::queue<std::packaged_task<void()>> queue_;
    std::mutex mutex_;
    std::condition_variable ready_;
    std::condition_variable idle_;
    bool stopping_{};
    std::size_t active_{};
};

template<class Function>
void parallel_for(std::size_t begin, std::size_t end, Function function, unsigned workers = 0) {
    if (end <= begin) return;
    const unsigned available = workers ? workers : std::max(1u, std::thread::hardware_concurrency());
    const unsigned count = static_cast<unsigned>(std::min<std::size_t>(available, end - begin));
    if (count <= 1) {
        for (std::size_t i = begin; i < end; ++i) function(i);
        return;
    }
    std::vector<std::thread> threads;
    threads.reserve(count);
    const std::size_t block = (end - begin + count - 1) / count;
    for (unsigned worker = 0; worker < count; ++worker) {
        const std::size_t first = begin + static_cast<std::size_t>(worker) * block;
        const std::size_t last = std::min(end, first + block);
        if (first >= last) break;
        threads.emplace_back([=, &function] {
            for (std::size_t i = first; i < last; ++i) function(i);
        });
    }
    for (auto& thread : threads) thread.join();
}

template<class Input, class Output, class Function>
void parallel_transform(const std::vector<Input>& input, std::vector<Output>& output,
                        Function function, unsigned workers = 0) {
    output.resize(input.size());
    parallel_for(0, input.size(), [&](std::size_t index) {
        output[index] = function(input[index]);
    }, workers);
}

template<class Value, class Function>
Value parallel_reduce(std::size_t begin, std::size_t end, Value initial,
                      Function function, unsigned workers = 0) {
    if (end <= begin) return initial;
    const unsigned available = workers ? workers : std::max(1u, std::thread::hardware_concurrency());
    const unsigned count = static_cast<unsigned>(std::min<std::size_t>(available, end - begin));
    std::vector<Value> partials(count, Value{});
    parallel_for(0, count, [&](std::size_t worker) {
        const std::size_t block = (end - begin + count - 1) / count;
        const std::size_t first = begin + worker * block;
        const std::size_t last = std::min(end, first + block);
        Value local{};
        for (std::size_t index = first; index < last; ++index) local += function(index);
        partials[worker] = std::move(local);
    }, count);
    for (const auto& value : partials) initial += value;
    return initial;
}

} // namespace coo::cpu
