#pragma once

#include <string>

namespace coo::audio {

bool initialize();
void shutdown();
bool available();
void set_master_volume(float volume);
float master_volume();

// Tonalite non bloquante generee par XAudio2.
bool play_tone(float frequency_hz, int duration_ms, float volume = 0.35f);

// Lecture WAV asynchrone pour les ressources audio simples.
bool play_wav_async(const std::wstring& path, bool loop = false);
void stop_wav();

// Compatibilite : bip synchrone Windows.
void beep(int frequency_hz, int duration_ms);

} // namespace coo::audio

