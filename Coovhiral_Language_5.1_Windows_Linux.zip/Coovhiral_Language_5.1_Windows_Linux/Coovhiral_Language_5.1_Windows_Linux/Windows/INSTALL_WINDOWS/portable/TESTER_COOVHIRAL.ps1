$ErrorActionPreference = 'Stop'

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Coo = Join-Path $Root 'coo.exe'
$Cooc = Join-Path $Root 'cooc.exe'
$TestRoot = Join-Path ([System.IO.Path]::GetTempPath()) ('coovhiral_test_' + [guid]::NewGuid().ToString('N'))
$Source = Join-Path $TestRoot 'test_installation.coo'
$WindowSource = Join-Path $Root 'examples\02_fenetre_directx.coo'
$WindowCpp = Join-Path $TestRoot 'fenetre.generated.cpp'
$WindowExe = Join-Path $TestRoot 'fenetre.exe'
$Retro = Join-Path $Root 'coo_retro.exe'

Write-Host '=============================================' -ForegroundColor Cyan
Write-Host '  TEST AVHIRAL COOVHIRAL STUDIO PRO 5.1.0' -ForegroundColor Cyan
Write-Host '=============================================' -ForegroundColor Cyan

try {
    if (-not (Test-Path -LiteralPath $Coo)) { throw 'coo.exe est introuvable.' }
    if (-not (Test-Path -LiteralPath $Cooc)) { throw 'cooc.exe est introuvable.' }
    if (-not (Test-Path -LiteralPath $Retro)) { throw 'coo_retro.exe est introuvable.' }

    New-Item -ItemType Directory -Path $TestRoot | Out-Null
    @'
app console
use core

fn main() {
    print "COOVHIRAL_TEST_OK"
    return 0
}
'@ | Set-Content -LiteralPath $Source -Encoding UTF8

    Write-Host '[1/6] Version du compilateur...'
    & $Cooc --version
    if ($LASTEXITCODE -ne 0) { throw 'La commande cooc --version a echoue.' }

    Write-Host '[2/6] Verification syntaxique...'
    & $Cooc --check $Source
    if ($LASTEXITCODE -ne 0) { throw 'La verification du fichier .coo a echoue.' }

    Write-Host '[3/6] Compilation et execution avec coo...'
    & $Coo $Source
    if ($LASTEXITCODE -ne 0) { throw 'La commande coo a echoue.' }

    Write-Host '[4/6] Verification du point d entree graphique WinMain...'
    & $Cooc --check --emit-cpp $WindowCpp $WindowSource
    if ($LASTEXITCODE -ne 0) { throw 'La generation C++ de la fenetre DirectX a echoue.' }
    $Generated = Get-Content -LiteralPath $WindowCpp -Raw
    if ($Generated -notmatch 'int WINAPI WinMain\(' -or $Generated -match 'int WINAPI wWinMain\(') {
        throw 'Le point d entree Windows genere est invalide.'
    }

    Write-Host '[5/6] Liaison reelle d une application DirectX Windows...'
    & $Cooc $WindowSource -o $WindowExe
    if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath $WindowExe)) {
        throw 'La liaison de l application DirectX a echoue.'
    }

    Write-Host '[6/6] Presence du moteur BASIC CPC/C64 integre...'
    $RetroInfo = Get-Item -LiteralPath $Retro
    if ($RetroInfo.Length -lt 1024) { throw 'coo_retro.exe semble incomplet.' }

    Write-Host ''
    Write-Host '[OK] Coovhiral, MSVC et le SDK Windows fonctionnent.' -ForegroundColor Green
}
catch {
    Write-Host ''
    Write-Host ('[ERREUR] ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Copiez le message complet pour le diagnostic.' -ForegroundColor Yellow
}
finally {
    if (Test-Path -LiteralPath $TestRoot) {
        Remove-Item -LiteralPath $TestRoot -Recurse -Force
    }
}
